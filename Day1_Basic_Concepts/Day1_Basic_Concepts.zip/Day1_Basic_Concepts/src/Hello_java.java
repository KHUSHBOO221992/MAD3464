/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author macstudent
 */
public class Hello_java {                  // class name should be simillar to file name & name begin with uppercase
    public static  void main(String[] args)
    {
        //  int khushbooBhatoia;           // value should be camel pattren as first word lowercase and second word uppercase
        int number   = 10;
        float percentage;
        char vowel = 'a';
        String firstName = "KB";
        
        System.out.println("VALUE OF NUMBER: " + number);  //ln used for new line,out for output  
        
        percentage = 78.6f;
        System.out.println("VALUE OF PERCENTAGE: " + percentage);
        System.out.println("Vowel: " + vowel);
        System.out.println("FIRST NAME: " + firstName);
        
        percentage = 10;
        //number = 10.23
        
        vowel  = 74;
        number = 'K';
        
        System.out.println("Vowel: " + vowel);
        System.out.println("VALUE OF NUMBER: " + number);
        
        System.out.println("TEST: " + 1 +  2);
        
        System.out.println(1 + 2 + "TEST ");
    }
}
