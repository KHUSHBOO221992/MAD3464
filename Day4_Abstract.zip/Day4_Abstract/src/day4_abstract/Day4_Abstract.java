package day4_abstract;

public class Day4_Abstract 
{

    public static void main(String[] args) 
    {
        
    }
    
}
