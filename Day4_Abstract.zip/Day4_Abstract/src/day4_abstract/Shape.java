package day4_abstract;

import java.io.PrintStream;

public class Shape 
{
    public static void main(String args[])
    {
        //MyShape obj1 = new MyShape();
       Circle c1 = new Circle();
       c1.draw();
       
    }
}

abstract class Myshape
{
   int x;
   int y;
   
   abstract void draw();
   
   void display(String msg)
   {
       System.out.println(msg);
   }
   
 }
class Circle extends MyShape
{
    @Override
    void draw()
    {
      System.out.println("Drawing Circle");
      super.x = 20;
      super.y = 30;
        PrintStream println = System.out.println(" x = " + super.x + " y = " +super.y);
    }
}

abstract class Rectangle extends MyShape
{
    int h;
    
}