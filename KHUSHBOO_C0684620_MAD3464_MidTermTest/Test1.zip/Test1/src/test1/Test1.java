package test1;

public class Test1 
{
    public static void main(String[] args) 
    {
       /* Player p1 = new Player();
        p1.readData();
        p1.displayData();
        
          Player p2 = new Player();
        p2.readData();
        p2.displayData();
        
        */
        
        Bowler Br1 = new Bowler();
        Br1.readData();
        Br1.displayData();
        
       /* Bowler Br2 = new Bowler();
        Br2.readData();
        Br2.displayData();
        
        */
        
        
        Batsman Bt1 = new Batsman();
        Bt1.readData();
        Bt1.displayData();
        
        /*  Batsman Bt2 = new Batsman();
        Bt2.readData();
        Bt2.displayData();
        */
        
        
    }
    
}
