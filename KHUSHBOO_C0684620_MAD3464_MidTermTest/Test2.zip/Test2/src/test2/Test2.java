package test2;

public class Test2 
{
    public static void main(String[] args) 
    {
        String str1="zanil";

        System.out.println(str1.length());
        
        String s1=str1.toUpperCase();
        
        System.out.println(s1);
        
        
    }
    
}
