/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package conditionstatments;

/**
 *
 * @author macstudent
 */
public class ConditionStatments {

    public static void main(String[] args) {
      /*  int number = 20;
       if(number > 10)
       {
         System.out.println("MORE THAN 10");
       }
       else if(number == 10)
               {
                   System.out.println("EQUAL TO 10");
               }
       
       switch(number)
       {
           case 10:
               System.out.println("VALUE = 10");
               break;
               case 20:
               System.out.println("VALUE = 20");
               break;
               case 30:
               System.out.println("VALUE = 30");
               break;
               default:
               System.out.println("NO MATCHING VALUE");
               break;
       }
       
       
       char vowel = 'a';
       switch(vowel)
       {
           case 'a':
               System.out.println("VOWEL");
               break;
               case 'e':
               System.out.println("VOWEL");
               break;
               case 'i':
               System.out.println("VOWEL");
               break;
               case 'o':
               System.out.println("VOWEL");
               break;
               case 'u':
               System.out.println("VOWEL");
               break;
               default:
               System.out.println("NOT A VOWEL");
               break;
               
       }
       
       String province = "ALBERTA";
       switch(province)
       {
           case "Ontario":
               System.out.println("ON");
               break;
           case "Alberta":
               System.out.println("AB");
               break;
           case "Prince Edward":
               System.out.println("PE");
               break;
           default:
               System.out.println("UNAVAILABLE");
               break;
       }
               
       int numbers[] = new int[5];
       
       int i;
       
       for(i=0;i<=numbers.length;i++)
       {
           //number[i] = 10;     error
           numbers[i] = (int)(Math.random()*100);
           System.out.println("NUMBERS [" + i + "] =" +numbers[i]);
       }
       double PI = Math.PI;
       double power = Math.pow(2,2);
       Math.sqrt(144);
       Math.abs(PI.VALUE);
       */

      
      
      
    }
    
}
